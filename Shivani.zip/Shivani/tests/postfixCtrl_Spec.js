describe('Test Controller', function(){
	beforeEach(angular.mock.module('postfixApp'));

    var $controller, $scope, controller;
	
    beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('postfixCtrl', { $scope: $scope });
    });
	
	it('should return postfix evaluation 5 if the input expression is 2 3 +', function() {
      $scope.input = '2 3 +';
      $scope.output = $scope.polishNotationCalculator($scope.input);
      expect($scope.output).toEqual(5);
    });
	it('should return postfix evaluation 25 if the input expression is 5 2 ^', function() {
      $scope.input = '5 2 ^';
      $scope.output = $scope.polishNotationCalculator($scope.input);
      expect($scope.output).toEqual(25);
    });
	it('should return postfix evaluation 4 if the input expression is 1 4 + 3 3 * -', function() {
      $scope.input = '1 4 + 3 3 * -';
      $scope.output = $scope.polishNotationCalculator($scope.input);
      expect($scope.output).toEqual(4);
    });
	it('should return postfix evaluation 1 if the input expression is 2 3 -', function() {
      $scope.input = '2 3 -';
      $scope.output = $scope.polishNotationCalculator($scope.input);
      expect($scope.output).toEqual(1);
    });
	it('should return postfix evaluation 14 if the input expression is 2 7 *', function() {
      $scope.input = '2 7 *';
      $scope.output = $scope.polishNotationCalculator($scope.input);
      expect($scope.output).toEqual(14);
    });
	it('should return error message and blank output if the input expression is 5 / * -', function() {
      $scope.input = '5 / * -';
      $scope.output = $scope.polishNotationCalculator($scope.input);
	  expect($scope.errorMessage).toEqual("Input format is invalid");
      expect($scope.output).toEqual("");
    });
});