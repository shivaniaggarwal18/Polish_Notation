var app=angular.module('postfixApp', []);

app.controller('postfixCtrl', function($scope){
	$scope.polishNotationCalculator = function(input){   
		var outputArray = [];		//output array
		var polishExp = input.split(" ");
		var x;
		var len = polishExp.length;
		$scope.showError = false;
		var errorMessage ="";   //Error message
		
		for(x=0;x<len;x++){
			if(!isNaN(polishExp[x])){
				outputArray.push(polishExp[x]);
			}
			else{
				var a = outputArray.pop();
				var b = outputArray.pop();
				var operator = polishExp[x];
				switch(operator){
					case "+": 
						outputArray.push(parseInt(a) + parseInt(b));
						break;
					case "-":
						outputArray.push(parseInt(a) - parseInt(b));
						break;
					case "*":
						outputArray.push(parseInt(a) * parseInt(b));
						break;
					case "/":
						outputArray.push(parseInt(a) / parseInt(b));
						break;
					case "^":
						outputArray.push(Math.pow(parseInt(b), parseInt(a)));
						break;					
				}
			}			
		}
		if(outputArray.length > 1 || outputArray.length <=0 || isNaN(outputArray[0])) {
			$scope.showError = true;
			$scope.errorMessage = "Input format is invalid";
			$scope.output = "";
		} 
		else if (outputArray[0] == 'Infinity'){
			$scope.output = "";
			$scope.showError = true;
			$scope.errorMessage = "Divide by 0 not allowed. Please enter a valid input!!";
		} else {
			$scope.output=outputArray.pop();			
		}
		return $scope.output;
	}
});



